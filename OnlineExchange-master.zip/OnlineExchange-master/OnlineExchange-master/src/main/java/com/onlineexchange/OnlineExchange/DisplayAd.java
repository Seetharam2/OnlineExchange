package com.onlineexchange.OnlineExchange;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.onlineexchange.Dao.DisplayAdsDao;
import com.onlineexchange.model.Ads;
import com.onlineexchange.model.Filter;

@Path("ads")
public class DisplayAd {
	@POST
	@Path("/displayad")
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public Ads displayAd(Filter filter)
	{
		DisplayAdsDao displayAdsDao = new DisplayAdsDao();
		return displayAdsDao.getAdDetails(filter);
	}

}
