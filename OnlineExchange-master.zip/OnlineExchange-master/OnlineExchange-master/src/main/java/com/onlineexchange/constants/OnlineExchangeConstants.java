package com.onlineexchange.constants;

public class OnlineExchangeConstants {
	public static final int CATEGORY_ELECTRONICS = 1;
	public static final int CATEGORY_MOBILES = 2;
	public static final int CATEGORY_FURNITURE = 3;
	public static final int CATEGORY_BIKES = 4;
	public static final int CATEGORY_CARS = 5;
	public static final int CATEGORY_RENT = 6;

}
