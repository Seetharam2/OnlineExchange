package com.onlineexchange.model;

import java.sql.Blob;
import java.sql.Timestamp;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.fasterxml.jackson.annotation.JsonFormat;

@XmlRootElement
@XmlType(propOrder = {"adId", "userId", "categoryId", "userName", "categoryName", "subCategoryName", "title", "adDescription", "brand", "state", "city", "images", "model", "makeYear", "milesDriven", "gasType", "price", "contactNumber", "datePosted", "adStatus"})
public class Ads {
	private int adId;
	private int userId;
	private int categoryId;
	private String userName;
	private String categoryName;
	private String subCategoryName;
	private String title;
	private String adDescription;
	private String brand;
	private String state;
	private String city;
	private Blob images;
	private String model;
	private int makeYear;
	private int milesDriven;
	private String gasType;
	private double price;
	private String contactNumber;
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss z", timezone = "CST")
	private Timestamp datePosted;
	private String adStatus;
	
	/**
	 * @return the adId
	 */
	public int getAdId() {
		return adId;
	}
	/**
	 * @param adId the adId to set
	 */
	public void setAdId(int adId) {
		this.adId = adId;
	}
	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}
	/**
	 * @return the categoryId
	 */
	public int getCategoryId() {
		return categoryId;
	}
	/**
	 * @param categoryId the categoryId to set
	 */
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the categoryName
	 */
	public String getCategoryName() {
		return categoryName;
	}
	/**
	 * @param categoryName the categoryName to set
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	/**
	 * @return the subCategoryName
	 */
	public String getSubCategoryName() {
		return subCategoryName;
	}
	/**
	 * @param subCategoryName the subCategoryName to set
	 */
	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the adDescription
	 */
	public String getAdDescription() {
		return adDescription;
	}
	/**
	 * @param adDescription the adDescription to set
	 */
	public void setAdDescription(String adDescription) {
		this.adDescription = adDescription;
	}
	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}
	/**
	 * @param brand the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the images
	 */
	public Blob getImages() {
		return images;
	}
	/**
	 * @param images the images to set
	 */
	public void setImages(Blob images) {
		this.images = images;
	}
	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}
	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}
	/**
	 * @return the makeYear
	 */
	public int getMakeYear() {
		return makeYear;
	}
	/**
	 * @param makeYear the makeYear to set
	 */
	public void setMakeYear(int makeYear) {
		this.makeYear = makeYear;
	}
	/**
	 * @return the milesDriven
	 */
	public int getMilesDriven() {
		return milesDriven;
	}
	/**
	 * @param milesDriven the milesDriven to set
	 */
	public void setMilesDriven(int milesDriven) {
		this.milesDriven = milesDriven;
	}
	/**
	 * @return the gasType
	 */
	public String getGasType() {
		return gasType;
	}
	/**
	 * @param gasType the gasType to set
	 */
	public void setGasType(String gasType) {
		this.gasType = gasType;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the contactNumber
	 */
	public String getContactNumber() {
		return contactNumber;
	}
	/**
	 * @param contactNumber the contactNumber to set
	 */
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	/**
	 * @return the datePosted
	 */
	public Timestamp getDatePosted() {
		return datePosted;
	}
	/**
	 * @param datePosted the datePosted to set
	 */
	public void setDatePosted(Timestamp datePosted) {
		this.datePosted = datePosted;
	}
	/**
	 * @return the adStatus
	 */
	public String getAdStatus() {
		return adStatus;
	}
	/**
	 * @param adStatus the adStatus to set
	 */
	public void setAdStatus(String adStatus) {
		this.adStatus = adStatus;
	}
}
