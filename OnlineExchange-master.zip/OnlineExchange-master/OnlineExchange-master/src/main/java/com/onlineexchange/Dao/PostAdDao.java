package com.onlineexchange.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import com.onlineexchange.model.Ads;
import com.onlineexchange.service.Service;

public class PostAdDao {
	ServiceDao serviceDao = new ServiceDao();
	Service service = new Service();
	Connection con;
	public Ads postAd(Ads postAd)
	{
		String postAdQuery = "insert into ads(user_id, cat_id, sub_cat_name, ad_title, ad_description, brand, state, city, images, model, make_year, miles_driven, gas_type, price, contact_no, date_posted, ad_status) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Timestamp ts = new Timestamp(System.currentTimeMillis());
		postAd.setDatePosted(ts);
		con = serviceDao.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement(postAdQuery, Statement.RETURN_GENERATED_KEYS);
			int userId = serviceDao.getUserId(postAd.getUserName());
			postAd.setUserId(userId);
			ps.setInt(1, userId);
			int categoryId = service.getCategoryId(postAd.getCategoryName());
			postAd.setCategoryId(categoryId);
			ps.setInt(2, postAd.getCategoryId());
			ps.setString(3, postAd.getSubCategoryName());
			ps.setString(4, postAd.getTitle());
			ps.setString(5, postAd.getAdDescription());
			ps.setString(6, postAd.getBrand());
			ps.setString(7, postAd.getState());
			ps.setString(8, postAd.getCity());
			ps.setBlob(9, postAd.getImages());
			ps.setString(10, postAd.getModel());
			ps.setInt(11, postAd.getMakeYear());
			ps.setInt(12, postAd.getMilesDriven());
			ps.setString(13, postAd.getGasType());
			ps.setDouble(14, postAd.getPrice());
			ps.setString(15, postAd.getContactNumber());
			ps.setTimestamp(16, postAd.getDatePosted());
			postAd.setAdStatus("Active");
			ps.setString(17, postAd.getAdStatus());
			int postedAds = ps.executeUpdate();
			if(postedAds==0)
			{
				throw new SQLException("PostAd failed, no rows affected.");
			}
			ResultSet rs = ps.getGeneratedKeys();
			if(rs.next())
			{
				postAd.setAdId(rs.getInt(1));
			}
			ps.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}	
		return postAd;	
	}
}
