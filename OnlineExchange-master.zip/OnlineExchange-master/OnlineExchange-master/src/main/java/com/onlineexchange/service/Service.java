package com.onlineexchange.service;

import com.onlineexchange.constants.OnlineExchangeConstants;
import com.onlineexchange.model.Filter;
import com.onlineexchange.model.Price;

public class Service {
	public int getCategoryId(String categoryName)
	{
		if(categoryName.equalsIgnoreCase("ELECTRONICS"))
			return OnlineExchangeConstants.CATEGORY_ELECTRONICS;
		else if(categoryName.equalsIgnoreCase("MOBILES"))
			return OnlineExchangeConstants.CATEGORY_MOBILES;
		else if(categoryName.equalsIgnoreCase("FURNITURE"))
			return OnlineExchangeConstants.CATEGORY_FURNITURE;
		else if(categoryName.equalsIgnoreCase("BIKES"))
			return OnlineExchangeConstants.CATEGORY_BIKES;
		else if(categoryName.equalsIgnoreCase("CARS"))
			return OnlineExchangeConstants.CATEGORY_CARS;
		else if(categoryName.equalsIgnoreCase("RENT"))
			return OnlineExchangeConstants.CATEGORY_RENT;
		else 
			return 0;	
	}
	public String getCategoryName(int categoryId)
	{
		if(categoryId == 1)
			return "ELECTRONICS";
		else if(categoryId == 2)
			return "MOBILES";
		else if(categoryId == 3)
			return "FURNITURE";
		else if(categoryId == 4)
			return "BIKES";
		else if(categoryId == 5)
			return "CARS";
		else if(categoryId == 6)
			return "RENT";
		else 
			return "NA";	
	}
	public String getDisplayAdsQuery(Filter filter)
	{
		String query ="select * from ads where";
		String displayAdsQuery ="select * from ads where";
		Price price = filter.getPrice();
		double minPrice;
		double maxPrice;
		if(filter!=null)
		{
			if(filter.getState()!=null && !filter.getState().isEmpty())
			{
				String state = "'" + filter.getState() + "'";
				displayAdsQuery = displayAdsQuery + " state = "+state;
			}
			if(filter.getCity()!=null && !filter.getCity().isEmpty())
			{
				String city = "'" + filter.getCity() + "'";
				if(displayAdsQuery.equalsIgnoreCase(query))
				{
					displayAdsQuery = displayAdsQuery + " city = "+city;
				}
				else
				{
					displayAdsQuery = displayAdsQuery + " and city = "+city;
				}
			}
			if(filter.getCategoryName()!=null && !filter.getCategoryName().isEmpty())
			{
				int categoryId = getCategoryId(filter.getCategoryName());
				if(displayAdsQuery.equalsIgnoreCase(query))
				{
					displayAdsQuery = displayAdsQuery + " cat_id = "+categoryId;
				}
				else
				{
					displayAdsQuery = displayAdsQuery + " and cat_id = "+categoryId;
				}
			}
			if(filter.getSubCategoryName()!=null && !filter.getSubCategoryName().isEmpty())
			{
				String subCategoryName = "'" + filter.getSubCategoryName() + "'";
				if(displayAdsQuery.equalsIgnoreCase(query))
				{
					displayAdsQuery = displayAdsQuery + " sub_cat_name = "+subCategoryName;
				}
				else
				{
					displayAdsQuery = displayAdsQuery + " and sub_cat_name = "+subCategoryName;
				}
			}
			if(price!=null)
			{
				minPrice = price.getMinPrice();
				maxPrice = price.getMaxPrice();
				if(displayAdsQuery.equalsIgnoreCase(query))
				{
					displayAdsQuery = displayAdsQuery + " price between "+minPrice;
					displayAdsQuery = displayAdsQuery + " and "+maxPrice;
				}
				else
				{
					displayAdsQuery = displayAdsQuery + " and price between "+minPrice;
					displayAdsQuery = displayAdsQuery + " and "+maxPrice;
				}
			}
		}
		System.out.println(displayAdsQuery);
		return displayAdsQuery;
	}
}
