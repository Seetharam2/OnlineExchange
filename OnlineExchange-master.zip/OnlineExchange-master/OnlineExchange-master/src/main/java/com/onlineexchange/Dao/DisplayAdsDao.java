package com.onlineexchange.Dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.onlineexchange.model.Ads;
import com.onlineexchange.model.Filter;
import com.onlineexchange.service.Service;

public class DisplayAdsDao {
	ServiceDao serviceDao = new ServiceDao();
	Service service = new Service();
	ArrayList<Ads> ads = new ArrayList<Ads>();
	Connection con;
	String getAdsQuery = "";
	public ArrayList<Ads> getAds(Filter filter)
	{
		String searchCriteria = filter.getSearchCriteria();
		if(searchCriteria!=null && !searchCriteria.isEmpty())
		{
			int cat_Id = service.getCategoryId(searchCriteria);
			getAdsQuery = "select * from ads where cat_id = "+ cat_Id;
			String[] searchWords = searchCriteria.split(" ");
			for(int i=0; i < searchWords.length; i++)
			{
				getAdsQuery = getAdsQuery + " OR sub_cat_name like " + "'%"+searchWords[i]+"%'" 
						+" OR ad_title like " + "'%"+searchWords[i]+"%'"+" OR ad_description like " + "'%"+searchWords[i]+"%'"
						+" OR brand like " + "'%"+searchWords[i]+"%'"+" OR state like " + "'%"+searchWords[i]+"%'" 
						+" OR city like " + "'%"+searchWords[i]+"%'" +" OR model like " + "'%"+searchWords[i]+"%'"
						+" OR make_year like " + "'%"+searchWords[i]+"%'" +" OR miles_driven like " + "'%"+searchWords[i]+"%'"
						+" OR gas_type like " + "'%"+searchWords[i]+"%'";
			}
			System.out.println(getAdsQuery);
		}
		else {
			getAdsQuery = service.getDisplayAdsQuery(filter);
		}
		try {
			con = serviceDao.getConnection();
			Statement st = con.createStatement();
			ResultSet rs;
			rs = st.executeQuery(getAdsQuery);
			while(rs.next())
			{
				Ads ad = new Ads();
				ad.setAdId(rs.getInt("ad_id"));
				ad.setUserId(rs.getInt("user_id"));
				int userId = ad.getUserId();
				ad.setUserName(serviceDao.getUserName(userId));
				int categoryId = rs.getInt("cat_id");
				String categoryName = service.getCategoryName(categoryId);
				ad.setCategoryName(categoryName);
				ad.setCategoryId(rs.getInt("cat_id"));
				ad.setSubCategoryName(rs.getString("sub_cat_name"));
				ad.setTitle(rs.getString("ad_title"));
				ad.setAdDescription(rs.getString("ad_description"));
				ad.setBrand(rs.getString("brand"));
				ad.setState(rs.getString("state"));
				ad.setCity(rs.getString("city"));
				ad.setImages(rs.getBlob("images"));
				ad.setModel(rs.getString("model"));
				ad.setMakeYear(rs.getInt("make_year"));
				ad.setMilesDriven(rs.getInt("miles_driven"));
				ad.setGasType(rs.getString("gas_type"));
				ad.setPrice(rs.getDouble("price"));
				ad.setContactNumber(rs.getString("contact_no"));
				ad.setDatePosted(rs.getTimestamp("date_posted"));
				ad.setAdStatus(rs.getString("ad_status"));
				ads.add(ad);
			}
			st.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ads;	
	}

	public Ads getAdDetails(Filter filter)
	{
		Ads ad = new Ads();
		ServiceDao serviceDao = new ServiceDao();
		Connection con = serviceDao.getConnection();
		String getAdDetailsQuery = "select * from ads where ad_id = " + filter.getAdId();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(getAdDetailsQuery);
			while(rs.next())
			{
				ad.setAdId(rs.getInt("ad_id"));
				ad.setUserId(rs.getInt("user_id"));
				int userId = ad.getUserId();
				ad.setUserName(serviceDao.getUserName(userId));
				int categoryId = rs.getInt("cat_id");
				String categoryName = service.getCategoryName(categoryId);
				ad.setCategoryName(categoryName);
				ad.setCategoryId(rs.getInt("cat_id"));
				ad.setSubCategoryName(rs.getString("sub_cat_name"));
				ad.setTitle(rs.getString("ad_title"));
				ad.setAdDescription(rs.getString("ad_description"));
				ad.setBrand(rs.getString("brand"));
				ad.setState(rs.getString("state"));
				ad.setCity(rs.getString("city"));
				ad.setImages(rs.getBlob("images"));
				ad.setModel(rs.getString("model"));
				ad.setMakeYear(rs.getInt("make_year"));
				ad.setMilesDriven(rs.getInt("miles_driven"));
				ad.setGasType(rs.getString("gas_type"));
				ad.setPrice(rs.getDouble("price"));
				ad.setContactNumber(rs.getString("contact_no"));
				ad.setDatePosted(rs.getTimestamp("date_posted"));
				ad.setAdStatus(rs.getString("ad_status"));
			}
			st.close();
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ad;
	}
}
