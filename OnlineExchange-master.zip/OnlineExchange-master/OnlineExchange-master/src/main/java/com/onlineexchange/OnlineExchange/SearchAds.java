package com.onlineexchange.OnlineExchange;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.onlineexchange.Dao.SearchAdsDao;
import com.onlineexchange.model.Ads;
import com.onlineexchange.model.Filter;

@Path("ads")
public class SearchAds {
	
	@POST
	@Path("/searchads")
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public ArrayList<Ads> searchAds(Filter filter)
	{
		SearchAdsDao searchAdsDao = new SearchAdsDao();
		return searchAdsDao.getAds(filter);
	}

}
