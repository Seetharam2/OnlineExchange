package com.onlineexchange.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import com.onlineexchange.model.UserRegistration;

public class RegistrationDao {
	
	public UserRegistration registeruser(UserRegistration userdetails)
	{
		String url = "jdbc:mysql://localhost:3306/onlineexchange";
		String user = "root";
		String password = "root";
		String registerQuery = "insert into users(first_name,last_name,email,phone_no,user_name,pass_word,created_at) values(?,?,?,?,?,?,?)";
		Timestamp ts = new Timestamp(System.currentTimeMillis());
		userdetails.setDateCreated(ts);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = con.prepareStatement(registerQuery, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, userdetails.getFirstName());
			ps.setString(2, userdetails.getLastName());
			ps.setString(3, userdetails.getEmail());
			ps.setString(4,userdetails.getPhoneNumber());
			ps.setString(5, userdetails.getUserName());
			ps.setString(6, userdetails.getPassword());
			ps.setTimestamp(7, userdetails.getDateCreated());
			int rowsCreated = ps.executeUpdate();
			if(rowsCreated==0)
			{
				throw new SQLException("User Registration failed, no rows affected.");
			}
			ResultSet rs = ps.getGeneratedKeys();
			if(rs.next())
			{
				userdetails.setUserId(rs.getInt(1));
			}
			ps.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return userdetails;
	}

}
