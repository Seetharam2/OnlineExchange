package com.onlineexchange.OnlineExchange;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.onlineexchange.model.Ads;
import com.onlineexchange.Dao.PostAdDao;

@Path("adpost")
public class PostAd {
	@POST
	@Path("/postad")
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public Ads postAd(Ads postAd)
	{
		PostAdDao postAdDao = new PostAdDao();
		return postAdDao.postAd(postAd);
	}

}
