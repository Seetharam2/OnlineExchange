package com.onlineexchange.OnlineExchange;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.onlineexchange.Dao.RegistrationDao;
import com.onlineexchange.model.UserRegistration;

@Path("registration")
public class Registration {
	@POST
	@Path("/register")
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public UserRegistration register(UserRegistration userDetails)
	{
		RegistrationDao registrationDao = new RegistrationDao();
		return registrationDao.registeruser(userDetails);	
	}
}
