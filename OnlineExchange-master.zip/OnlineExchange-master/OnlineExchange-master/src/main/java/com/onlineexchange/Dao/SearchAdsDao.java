package com.onlineexchange.Dao;

import java.util.ArrayList;

import com.onlineexchange.model.Ads;
import com.onlineexchange.model.Filter;

public class SearchAdsDao {
	public ArrayList<Ads> getAds(Filter filter)
	{
		DisplayAdsDao displayAdsDao = new DisplayAdsDao();
		return displayAdsDao.getAds(filter);
	}

}
