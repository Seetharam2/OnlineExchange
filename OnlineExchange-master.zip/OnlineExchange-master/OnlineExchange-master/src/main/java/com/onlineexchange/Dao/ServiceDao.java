package com.onlineexchange.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServiceDao {
	Connection con;
	public Connection getConnection()
	{
		String url = "jdbc:mysql://localhost:3306/onlineexchange";
		String user = "root";
		String password = "root";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	public int getUserId(String userName) throws SQLException
	{
		int userId = 0;
		String getUserIdQuery = "select user_id from users where user_name = ?";
		con = getConnection();
		PreparedStatement ps = con.prepareStatement(getUserIdQuery);
		ps.setString(1, userName);
		ResultSet rs = ps.executeQuery();
		if(rs.next())
		{
			userId = rs.getInt("user_id");
		}
		return userId;
	}
	public String getUserName(int userId) throws SQLException
	{
		String userName = "";
		String getUserNameQuery = "select user_name from users where user_id = ?";
		con = getConnection();
		PreparedStatement ps = con.prepareStatement(getUserNameQuery);
		ps.setInt(1, userId);;
		ResultSet rs = ps.executeQuery();
		if(rs.next())
		{
			userName = rs.getString("user_name");
		}
		return userName;
	}

}
