package com.onlineexchange.OnlineExchange;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.onlineexchange.Dao.ValidateLoginDao;
import com.onlineexchange.model.Login;

@Path("login")
public class ValidateLogin {
	@POST
	@Path("/validatelogin")
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public Login validateLogin(Login loginDetails)
	{
		ValidateLoginDao validateLoginDao = new ValidateLoginDao();
		return validateLoginDao.validateLogin(loginDetails);
		
	}
}
