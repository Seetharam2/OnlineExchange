package com.onlineexchange.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.onlineexchange.model.Login;

public class ValidateLoginDao {
	ServiceDao serviceDao = new ServiceDao();
	Connection con;
	String validateLoginQuery = "select * from users where email= ? and user_name = ? and pass_word = ?";
	public Login validateLogin(Login loginDetails)
	{
		try
		{
			con = serviceDao.getConnection();
			PreparedStatement ps = con.prepareStatement(validateLoginQuery);
			ps.setString(1, loginDetails.getEmail());
			ps.setString(2, loginDetails.getUserName());
			ps.setString(3, loginDetails.getPassword());
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				loginDetails.setUserId(rs.getInt("user_id"));
				loginDetails.setFirstName(rs.getString("first_name"));
				loginDetails.setLastName(rs.getString("last_name"));
				loginDetails.setEmail(rs.getString("email"));
				loginDetails.setPhoneNumber(rs.getString("phone_no"));
				loginDetails.setUserName(rs.getString("user_name"));
				loginDetails.setPassword(rs.getString("pass_word"));
				loginDetails.setDateCreated(rs.getTimestamp("created_at"));
				loginDetails.setUserFound("YES");
				System.out.println(rs.getString("user_name"));
			}
			else
				loginDetails.setUserFound("NO");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return loginDetails;
	}
}
